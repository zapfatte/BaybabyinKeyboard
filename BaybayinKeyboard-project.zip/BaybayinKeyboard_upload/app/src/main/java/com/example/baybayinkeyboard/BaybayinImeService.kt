package com.example.baybayinkeyboard


import android.inputmethodservice.InputMethodService
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class BaybayinImeService : InputMethodService() {
    private var shifted = false
    private lateinit var customTypeface: Typeface

    override fun onCreate() {
        super.onCreate()
        customTypeface = Typeface.createFromAsset(assets, "fonts/baybayin_modern_mono.ttf")
    }

    override fun onCreateInputView(): View {
        return KeyboardRoot().build()
    }

    private inner class KeyboardRoot {
        private val bg = Color.rgb(237, 240, 245)
        private val ink = Color.rgb(53, 65, 71)
        private val keyBg = Color.rgb(237, 240, 245)


        fun build(): View {
            val root = LinearLayout(this@BaybayinImeService).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(7), dp(6), dp(7), dp(6))
                setBackgroundColor(bg)
            }
            // Number row: labels are drawn using the bundled Baybayin font, not the system font.
            root.addView(row(listOf("1","2","3","4","5","6","7","8","9","0"), 0.72f, true))
            root.addView(row(listOf("q","w","e","r","t","y","u","i","o"), 1.0f, true))
            root.addView(row(listOf("a","s","d","f","g","h","j","k","l"), 1.0f, true))
            root.addView(makeActionRow())
            root.addView(makeBottomRow())
            return root
        }


        private fun row(keys: List<String>, heightWeight: Float, fontLabels: Boolean): LinearLayout {
            val line = LinearLayout(this@BaybayinImeService).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            keys.forEach { key ->
                val output = keyToBaybayin(key)
                val label = if (fontLabels) key else output
                line.addView(keyView(label, output, 1f, 42))
            }
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(47))
            params.bottomMargin = dp(3)
            line.layoutParams = params
            return line
        }

        private fun makeActionRow(): LinearLayout {
            val line = LinearLayout(this@BaybayinImeService).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            line.addView(actionKey("⇧", 1.4f) { shifted = !shifted; refreshKeys() })
            listOf("z","x","c","v","b","n","m").forEach { k ->
                line.addView(keyView(k, keyToBaybayin(k), 1f, 42))
            }
            line.addView(actionKey("⌫", 1.5f) { currentInputConnection?.deleteSurroundingText(1, 0) })
            line.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50))
            return line
        }

        private fun makeBottomRow(): LinearLayout {
            val line = LinearLayout(this@BaybayinImeService).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            line.addView(actionKey("123", 1.3f) { showSymbols() })
            line.addView(actionKey(",", 0.7f) { commit(",") })
            line.addView(actionKey("space", 4f) { commit(" ") }, LinearLayout.LayoutParams(0, dp(46), 4f))
            line.addView(actionKey(".", 0.7f) { commit(".") })
            line.addView(actionKey("↵", 1.3f) { currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)); currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER)) })
            line.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50))
            return line
        }

        private fun keyView(label: String, output: String, weight: Float, h: Int): View {
            val tv = TextView(this@BaybayinImeService).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = if (label.length > 1) 16f else 25f
                setTextColor(ink)
                typeface = customTypeface
                background = rounded(keyBg, 6)
                setOnClickListener { commit(if (shifted) output.uppercase() else output); if (shifted) shifted = false }
            }
            val lp = LinearLayout.LayoutParams(0, dp(h), weight)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            return tv.apply { layoutParams = lp }
        }

        private fun actionKey(label: String, weight: Float, action: () -> Unit): View {
            val tv = TextView(this@BaybayinImeService).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 17f
                setTextColor(ink)
                background = rounded(Color.rgb(210, 216, 221), 7)
                setOnClickListener { action() }
            }
            val lp = LinearLayout.LayoutParams(0, dp(44), weight)
            lp.setMargins(dp(3), dp(2), dp(3), dp(2))
            tv.layoutParams = lp
            return tv
        }

        private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
        private fun commit(text: String) { currentInputConnection?.commitText(text, 1) }
        private fun showSymbols() { commit("123") }
        private fun refreshKeys() { /* shift state is applied on next press; UI refresh follows in v0.2 */ }
        private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    }


    // First prototype mapping. We will revise this table to match your reference's exact key order.
    private fun keyToBaybayin(key: String): String = when (key.lowercase()) {
        "a" -> "ᜀ"; "b" -> "ᜊ"; "c" -> "ᜃ"; "d" -> "ᜇ"; "e" -> "ᜁ"; "f" -> "ᜉ";
        "g" -> "ᜄ"; "h" -> "ᜑ"; "i" -> "ᜒ"; "j" -> "ᜌ"; "k" -> "ᜃ"; "l" -> "ᜎ";
        "m" -> "ᜋ"; "n" -> "ᜈ"; "o" -> "ᜂ"; "p" -> "ᜉ"; "q" -> "ᜅ"; "r" -> "ᜇ";
        "s" -> "ᜐ"; "t" -> "ᜆ"; "u" -> "ᜓ"; "v" -> "ᜏ"; "w" -> "ᜏ"; "x" -> "᜔";
        "y" -> "ᜌ"; "z" -> "᜔"; else -> key
    }
}
